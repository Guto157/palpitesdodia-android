package com.br.palpitedodia.app;

import com.getcapacitor.BridgeActivity;

public class MainActivity extends BridgeActivity {}
